For you, PA1NK113R

The Rest of the sprites will better off be taken from the femalezombie.wad file.